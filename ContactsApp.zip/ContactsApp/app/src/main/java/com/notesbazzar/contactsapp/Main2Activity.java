package com.notesbazzar.contactsapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    ListView li;




    Integer[] imgid={
            R.drawable.call,R.drawable.sms,
            R.drawable.map,R.drawable.download
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("manish","click2");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2main);



        String[] maintitle ={
                "Call" ,"Sms",
                "Map","Whatsapp"
        };

        final MyListAdapter adapter=new MyListAdapter(this, maintitle,imgid);
        li=(ListView)findViewById(R.id.list);
        li.setAdapter(adapter);

        li.setOnItemClickListener(new AdapterView.OnItemClickListener() {



            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {

                    Intent callIntent = new Intent(Intent.ACTION_DIAL);
                    callIntent.setData(Uri.parse("tel:"+ getIntent().getStringExtra("no") ));
                    startActivity(callIntent);
                }

                else if(position == 1) {
                    sendSMSMessage();
                }

                else if(position == 2) {

                    double latitude = 31.708371;
                    double longitude = 76.527356;
                    String label = "NIT Hamirpur" ;
                    String uriBegin = "geo:" + latitude + "," + longitude;
                    String query = latitude + "," + longitude + "(" + label + ")";
                    String encodedQuery = Uri.encode(query);
                    String uriString = uriBegin + "?q=" + encodedQuery + "&z=16";
                    Uri uri = Uri.parse(uriString);
                    Intent mapIntent = new Intent(android.content.Intent.ACTION_VIEW, uri);
                    startActivity(mapIntent);
                    Log.d("manish","map");
                }
                else if(position==3) {
                    openWhatsApp();
                } else
                    Toast.makeText(Main2Activity.this, "You didn't choose any action", Toast.LENGTH_SHORT).show();

            }
        });



    }
    private void sendSMSMessage() {
        try {
            Uri uri = Uri.parse("smsto:" + getIntent().getStringExtra("no"));
            // No permisison needed
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO, uri);
            // Set the message to be sent
            smsIntent.putExtra("Manish", "Hello");
            startActivity(smsIntent);
        } catch (Exception e) {
            Toast.makeText(this,
                    "SMS faild, please try again later!",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
    public void openWhatsApp(){
        View view;
        PackageManager pm=getPackageManager();
        try {



            Intent sendIntent = new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:" + "" + getIntent().getStringExtra("no") + "?body=" + ""));
            sendIntent.setPackage("com.whatsapp");
            startActivity(sendIntent);
        }
        catch (Exception e){
            e.printStackTrace();
            Toast.makeText(Main2Activity.this,"it may be you dont have whats app",Toast.LENGTH_LONG).show();

        }
    }
}
